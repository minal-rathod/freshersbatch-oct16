import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http'; 
import { RouterModule } from '@angular/router'; 
import {Router} from '@angular/router';

import { AppComponent }  from './app.component';
import { HomeComponent }  from './components/homeComponent/homeComponent.component';
import { PostAdd } from "./components/postAdd/postAdd.component";
import { loginRegister } from "./components/login-register/login-registerComponent";


@NgModule({
  imports:      [ BrowserModule , FormsModule , HttpModule ,
        RouterModule.forRoot([
                      {path: '', component: HomeComponent}, 
                      {path: 'register', component: loginRegister}])],
  declarations: [ AppComponent,HomeComponent,PostAdd,loginRegister],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
