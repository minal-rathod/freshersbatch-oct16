import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<header></header> <br> <register></register> <br><footer> </footer>'
})
export class AppComponent  { }
