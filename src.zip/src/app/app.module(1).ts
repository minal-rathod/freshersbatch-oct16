import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';
import { headerComponent } from "./components/headerComponent";
import { footerComponent } from "./components/footerComponent";
import { indexFinal } from "./components/indexfinalComponent";
import { Register } from "./components/registerComponent";

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent,headerComponent,footerComponent,indexFinal, Register ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
