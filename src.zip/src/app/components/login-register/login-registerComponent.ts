import { Component } from '@angular/core';
import {RegistrationService} from '../../services/registrationService/registrationService.service'
import {LoginService} from '../../services/loginService/loginService.service'
import { Router } from "@angular/router";
import { CategoriesService } from "../../services/categoriesServices/categoriesService.service";
import {ActivatedRoute} from '@angular/router'
@Component({
  selector: 'login-register',
  templateUrl: `./login-register.html`,
})
export class loginRegister{
    storeReg:any;
constructor(private router: Router){

}

   onClickRegister(fnameRef:string , lnameRef:string , unameRef:string , passwordRef:string ,emailRef:string, phoneRef:string):void{
            this.storeReg = 
                {firstName:fnameRef,
                lastName:lnameRef ,
                userName:unameRef , 
                password:passwordRef , 
                email:emailRef , 
                phone:phoneRef
            };
            console.log(this.storeReg);
                 /*this.regService.sendRegDetail(this.storeReg).subscribe((data:any)=> { 
                               
                             console.log('Received products: ', data); 
                });*/                this.router.navigate(['/register']);
    }
}